package de.prowebdev.wissensduell.routing

import de.prowebdev.wissensduell.storage.YamlTeacherDAO
import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*

fun Route.configureTeacherRoutes() {
    post("/teacher") {
        val name = call.receive<String>()
        val teacher = teacherDAO.createTeacher(name)
        call.respond(HttpStatusCode.Created, teacher)
    }
    get("/teachers") {
        val teachers = (teacherDAO as YamlTeacherDAO).teachers
        call.respond(HttpStatusCode.OK, teachers)
    }
}
